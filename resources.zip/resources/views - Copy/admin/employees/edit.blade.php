@extends('layouts.app')

@section('content')
<style>
:root {
    --primary-green: #1b3e86;
    --accent-orange: #1b3e86;
    --text-dark: #1e293b;
    --border-radius: 12px;
    --shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
}

/* Main Record Card */
.edit-employee-card {
    background: #fff;
    border: 1px solid #eef2f6;
    border-radius: 16px;
    box-shadow: var(--shadow);
    overflow: hidden;
}

.card-header-styled {
    padding: 1.5rem 2rem;
    border-bottom: 2px solid #f8fafc;
    border-top: 4px solid var(--accent-orange);
    /* Orange for edit mode */
    background: #fff;
}

.card-title-custom {
    font-weight: 800;
    color: var(--text-dark);
    letter-spacing: -0.5px;
}

/* Form Sectioning */
.section-label {
    font-size: 0.75rem;
    font-weight: 800;
    text-transform: uppercase;
    color: var(--accent-orange);
    letter-spacing: 1.2px;
    margin-bottom: 1.5rem;
    display: flex;
    align-items: center;
    gap: 10px;
}

.section-label::after {
    content: '';
    flex: 1;
    height: 1px;
    background: #f1f5f9;
}

/* Inputs & Labels */
.form-label {
    font-weight: 700;
    color: #475569;
    font-size: 0.85rem;
    margin-bottom: 0.6rem;
}

.form-control,
.form-select {
    border-radius: 10px;
    padding: 0.8rem 1rem;

    background-color: #fdfdfe;
    transition: all 0.2s ease;
    font-weight: 500;
}

.form-control:focus,
.form-select:focus {
    border-color: var(--accent-orange);
    background-color: #fff;
    box-shadow: 0 0 0 4px rgba(247, 148, 30, 0.1);
}

/* Multiple Select Box */
#cluster_stores {
    background-image: none;
    padding: 10px;
    border-radius: 10px;
    border: 1.5px solid #edf2f7;
}

/* Submit Button */
.btn-update {
    background: var(--accent-orange);
    border: none;
    padding: 12px 35px;
    border-radius: 10px;
    font-weight: 700;
    color: #fff;
    transition: all 0.3s ease;
    box-shadow: 0 4px 12px rgba(247, 148, 30, 0.2);
}

.btn-update:hover {
    background: #1b3e86;
    transform: translateY(-2px);
    box-shadow: 0 6px 18px rgba(247, 148, 30, 0.3);
}

.btn-cancel {
    border-radius: 10px;
    padding: 12px 25px;
    font-weight: 600;
}
</style>

<div class="card edit-employee-card mb-4">
    <div class="card-header-styled d-flex justify-content-between align-items-center">
        <h5 class="card-title-custom mb-0">Edit Employee Details</h5>
    </div>

    <div class="card-body p-4 p-md-5">
        <form method="POST" id="frm_create" action="{{ route('admin.employees.update', $employee) }}">
            @csrf @method('PUT')

            <!-- Identification Section -->
            <div class="section-label">
                <i class="ti ti-id fs-5"></i> Identification
            </div>
            <div class="row g-4 mb-4">
                <div class="col-md-6">
                    <label for="c_employee_code" class="form-label">Employee Code *</label>
                    <input type="text" id="c_employee_code" name="c_employee_code"
                        value="{{ old('c_employee_code', $employee->c_employee_code) }}"
                        data-message="Please add Employee Code" class="form-control mandatory" disabled>
                    @error('c_employee_code')
                    <div class="text-danger mt-1">{{ $message }}</div>
                    @enderror
                </div>

                <div class="col-md-6">
                    <label for="c_employee_name" class="form-label">Employee Name *</label>
                    <input type="text" id="c_employee_name" name="c_employee_name"
                        value="{{ old('c_employee_name', $employee->c_employee_name) }}"
                        data-message="Please enter Employee Name" class="form-control mandatory">
                    @error('c_employee_name')
                    <div class="text-danger mt-1">{{ $message }}</div>
                    @enderror
                </div>
            </div>


            <div id="password_section" style="{{ $errors->has('password') ? 'display:block;' : 'display:none;' }}"
                class="mt-3">
                <div class="row">
                    <div class="col-md-6">
                        <label class="form-label">New Password</label>
                        <input type="password" name="password" class="form-control" autocomplete="new-password">
                        @error('password')
                        <div class="text-danger mt-1">{{ $message }}</div>
                        @enderror

                    </div>

                    <div class="col-md-6">
                        <label class="form-label">Confirm Password</label>
                        <input type="password" name="password_confirmation" class="form-control"
                            autocomplete="new-password">

                    </div>

                </div>
            </div>

            <!-- Role Section -->
            <div class="section-label">
                <i class="ti ti-briefcase fs-5"></i> Role & Assigment
            </div>


            <div class="row g-4 mb-4">
                <div class="col-md-6">
                    <input type="hidden" name="pre_designation_id" value="{{ $employee->n_designation_id}}">
                    <label for="n_designation_id" class="form-label">Designation *</label>
                    <select id="n_designation_id" name="n_designation_id" class="form-select mandatory "
                        data-message="Please select a Designation">
                        <option value="">Select Designation</option>
                        @foreach($designations as $designation)
                        @php
                        $desigName = strtoupper(trim($designation->c_designation));
                        $storeRequired = in_array($desigName, ['CSA', 'C&A', 'SM']) ? 1 : 0;
                        @endphp
                        <option value="{{ $designation->n_designation_id }}" data-store="{{ $storeRequired }}"
                            {{ old('n_designation_id', $employee->n_designation_id) == $designation->n_designation_id ? 'selected' : '' }}>
                            {{ $designation->c_designation }}
                        </option>
                        @endforeach
                    </select>

                    @error('account_number')
                    <div class="text-danger mt-1">{{ $message }}</div>
                    @enderror

                </div>
                <div class="col-md-6">

                    <label for="reporting_to" class="form-label">
                        Reporting Manager
                    </label>
                    <select name="reporting_to" id="reporting_to" class="form-select">
                        <option value="">Select Reporting Manager</option>
                    </select>

                    @error('reporting_to')
                    <small class="text-danger">{{ $message }}</small>
                    @enderror
                </div>

            </div>
            <!-- Section 3: Account Details -->
            <div class="section-label">
                <i class="ti ti-building-bank fs-5"></i> Account Details
            </div>
            <div class="row g-4 mb-4">
                <div class="col-md-6">
                    <label for="account_number" class="form-label">Account Number *</label>
                    <input type="text" id="account_number" name="account_number"
                        value="{{ old('account_number', $kyc ? $kyc->account_number : '') }}"
                        data-message="Please add Account Number" class="form-control mandatory" placeholder="ACC-001">
                    @error('account_number')
                    <div class="text-danger mt-1">{{ $message }}</div>
                    @enderror
                </div>

                <div class="col-md-6">
                    <label for="ifsc_code" class="form-label">IFSC Code *</label>
                    <input type="text" id="ifsc_code" name="ifsc_code"
                        value="{{ old('ifsc_code', $kyc ? $kyc->ifsc_code : '') }}"
                        data-message="Please enter IFSC Code" class="form-control mandatory"
                        placeholder="Enter IFSC code">
                    @error('ifsc_code')
                    <div class="text-danger mt-1">{{ $message }}</div>
                    @enderror
                </div>
                <div class="col-md-6">
                    <label for="ifsc_code" class="form-label">Bank Name *</label>
                    <input type="text" id="bank_name" name="bank_name"
                        value="{{ old('bank_name', $kyc ? $kyc->bank_name : '') }}"
                        data-message="Please enter Bank name" class="form-control mandatory"
                        placeholder="Enter Bank Name">
                    @error('bank_name')
                    <div class="text-danger mt-1">{{ $message }}</div>
                    @enderror
                </div>
                <div class="col-md-6">
                    <label for="ifsc_code" class="form-label">Branch Name *</label>
                    <input type="text" id="branch_name" name="branch_name"
                        value="{{ old('bank_branch', $kyc ? $kyc->bank_branch : '') }}"
                        data-message="Please enter branch name" class="form-control mandatory"
                        placeholder="Enter Branch Name">
                    @error('branch_name')
                    <div class="text-danger mt-1">{{ $message }}</div>
                    @enderror
                </div>
            </div>



            <!-- Contact Section -->
            <div class="section-label">
                <i class="ti ti-mail fs-5"></i> Communication & Status
            </div>
            <div class="row g-4 mb-5">
                <div class="col-md-8">
                    <label for="c_employee_email" class="form-label">Work Email Address *</label>
                    <input type="email" id="c_employee_email" name="c_employee_email"
                        value="{{ old('c_employee_email', $employee->c_employee_email) }}"
                        data-message="Please enter an Email Address" class="form-control mandatory" readonly>
                    @error('c_employee_email')
                    <div class="text-danger mt-1">{{ $message }}</div>
                    @enderror
                </div>

                <div class="col-md-4">
                    <label for="c_status" class="form-label">Account Status *</label>
                    <select id="c_status" name="c_status" class="form-select mandatory"
                        data-message="Please select Status">
                        <option value="">Select Status</option>
                        <option value="Y" {{ old('c_status', $employee->c_status) === 'Y' ? 'selected' : '' }}>Active
                        </option>
                        <option value="N" {{ old('c_status', $employee->c_status) === 'N' ? 'selected' : '' }}>Inactive
                        </option>
                    </select>
                    @error('c_status')
                    <div class="text-danger mt-1">{{ $message }}</div>
                    @enderror
                </div>
            </div>

            <div class="d-flex gap-3 pt-4 border-top">
                <button type="submit" id="btn_create" class="btn btn-update">
                    <i class="ti ti-device-floppy me-1"></i> Update Record
                </button>

                <button type="button" id="btn_edit_password" class="btn btn-update">
                    <i class="ti ti-lock me-1"></i> Change Password
                </button>
                <a href="{{ route('admin.employees.index') }}" class="btn btn-outline-secondary btn-cancel">Cancel</a>
            </div>
        </form>
    </div>
</div>
@push('scripts')
<script>
success: function(data) {

    let options = '<option value="">Select Reporting Manager</option>';

    $.each(data, function(index, item) {

        options += `
            <option value="${item.n_designation_id}">
                ${item.c_designation}
            </option>
        `;
    });

    $('#reporting_to').html(options);
}
</script>
@endpush
@endsection